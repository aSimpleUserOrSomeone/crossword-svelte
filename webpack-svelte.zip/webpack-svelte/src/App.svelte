<script>
	var randomWords = require('random-words')
	$: dlugosc = 3
	var hasla = []
	var opisy = []
	var slowo = ''
	async function getDefinitions(tablica) {
		hasla.forEach((h) => {
			const fetchData = fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${h}`)
			console.log(fetchData)
		})
	}

	const newSlowo = () => {
		if (dlugosc < 3) {
			dlugosc = 3
		} else if (dlugosc > 14) {
			dlugosc = 14
		}
		while (slowo.length != dlugosc) {
			slowo = randomWords({ exactly: 1, maxLength: dlugosc })[0]
		}
		hasla = []
		for (var i = 0; i < slowo.length; i++) {
			const ch = slowo[i]
			while (true) {
				const haslo = randomWords({ exactly: 1 })[0]
				if (haslo.includes(ch)) {
					hasla.push(haslo)
					break
				}
			}
		}

		getDefinitions(hasla)
	}
</script>

<main>
	<h1>Crossword!</h1>
	<p>Długość krzyżówki: <input type="number" bind:value={dlugosc} on:change={newSlowo} /></p>

	<h2>Długość: {dlugosc}</h2>
	<h3>Słowo: {slowo}</h3>
	<h3>Hasła: {hasla}</h3>
	<div class="crossword" />
</main>

<style>
	main {
		text-align: center;
		padding: 1em;
		max-width: 240px;
		margin: 0 auto;
	}

	h1 {
		color: #ff3e00;
		text-transform: uppercase;
		font-size: 4em;
		font-weight: 100;
	}

	@media (min-width: 640px) {
		main {
			max-width: none;
		}
	}
</style>
